//This class alerts the Player class when a user presses and/or releases a button

import java.awt.event.*;
import java.io.*;
import java.util.*;
import java.awt.*;

public class KeyInput extends KeyAdapter
{
	private boolean[] keys;
	//Player player;
	String fileName;					//The name of the .txt file that the controls are saved in
	private int shoot;
	private int jump;
	private int left;					//Correspond to the index of the specific key
	private int right;					//That the player presses to do an action
	private int up;
	private int down;
/*
    public KeyInput(String f) 
    {
    	fileName = f;
    	Scanner inFile = new Scanner(new BufferedReader(new FileReader(fileName)));
    	
    	shoot = inFile.nextInt();
    	jump = inFile.nextInt();
    	left = inFile.nextInt();
    	right = inFile.nextInt();
    	up = inFile.nextInt();
    	down = inFile.nextInt();
    	
    	inFile.close();
    }
    
    public void keyTyped(KeyEvent e) {}
    
    public void keyPressed(KeyEvent e) 
    {
    	keys[e.getKeyCode()] = true;
    	switch (e.getKeyCode())
    	{
    		case shoot:
    			player.setIsShooting(true);
    			break;
    		case jump:
    			player.setIsJumping(true);
    			break;
    		case left:
    			player.setIsMovingLeft(true);
    			break;
    		case right:
    			player.setIsMovingRight(true);
    			break;
    		case up:
    			player.setIsMovingUp(true);
    			break;
    		case down:
    			player.setIsMovingDown(true);
    			break;
    		default: break;
    	}
    }
    
    public void keyReleased(KeyEvent e) 
    {
        keys[e.getKeyCode()] = false;
        switch (e.getKeyCode())
    	{
    		case shoot:
    			player.setIsShooting(false);
    			break;
    		case jump:
    			player.setIsJumping(false);
    			break;
    		case left:
    			player.setIsMovingLeft(false);
    			break;
    		case right:
    			player.setIsMovingRight(false);
    			break;
    		case up:
    			player.setIsMovingUp(false);
    			break;
    		case down:
    			player.setIsMovingDown(false);
    			break;
    		default: break;
    	}
    }
    
    public void exit()
    {
    	PrintWriter outFile = new PrintWriter(new BufferedWriter (new FileWriter (fileName)));
    	outFile.println(shoot);
    	outFile.println(jump);
    	outFile.println(left);
    	outFile.println(right);
    	outFile.println(up);
    	outFile.println(down);
    }*/
}