/**
 * @(#)Player.java
 *
 *
 * @author 
 * @version 1.00 2016/4/23
 */

import java.awt.*;
import java.awt.image.*;
import javax.imageio.*;
import javax.swing.*;

public class Player extends Rectangle
{
	int speed;
	int vx;
	int vy;
    int width;
    int height;
    BufferedImage idleTop;
    BufferedImage idleBottom;
	boolean isJumping;
	boolean isShooting;

    public Player(int nx, int ny) 
    {
        super(nx, ny, 20, 20);
        idleTop  = ImageTools.initializeImage("Finished Sprites\\sargeIdle0.png");
        width = idleTop.getWidth();
        height = idleTop.getHeight();
        idleBottom  = ImageTools.initializeImage("Finished Sprites\\sargeStanding.png");
    }

    public int getIntX()	{	return x;	}
    public int getIntY()	{	return y;	}
    public int getIntWidth()	{	return width;	}
    public int getIntHeight()	{	return height;	}
    
    public void setIsShooting(boolean b)	{	isShooting = b;	}
    public void setIsJumping(boolean b)		{	isJumping = b;	}
    public void setIsMovingLeft(boolean b)	{	vx = (vx > 0) ? 0 : -vx;	}
	public void setIsMovingRight(boolean b)	{	vx = (vx < 0) ? 0 : vx;		}
	public void setIsMovingUp(boolean b)	{	/*Do stuff*/				}
	public void setIsMovingDown(boolean b)	{	/*Do stuff*/				}

    public void draw(SubMap sm)
    {
        sm.getGraphics().drawImage(idleTop,x-width/2-sm.getIntX(),y-height/2-sm.getIntY(),null);
        sm.getGraphics().drawImage(idleBottom,x-width/2-sm.getIntX(),y-height/2-sm.getIntY(),null);
    }
}