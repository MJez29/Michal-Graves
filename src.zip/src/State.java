//All the possible states that the game can be in

public enum State 
{
	GAME,
	MENU,
	CHARACTER_SELECTION    
};